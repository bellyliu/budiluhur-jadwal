__VERSION__ = "1.0.0"
__BY__ = "yanwarsolahudinn@gmail.com"

URL_DEPAN = "http://jadwal.budiluhur.ac.id/"
URL_POST = "http://jadwal.budiluhur.ac.id/fakultas.php"
SELECT_TAG_NAME = "kdfak"
